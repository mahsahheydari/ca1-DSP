bild = imread('coffee.jpg');
bild=rgb2gray(bild);

% dge detection kernel
edge_det=[-1 -1 -1;-1 8 -1 ; -1 -1 -1]
edge_det_final= conv2(bild,edge_det);
figure(20)
imshow(edge_det_final,[])
title(' Edge Detection kernel');

% identity kernel
id=[0 0 0;0 1 0 ; 0 0 0]
id_final= conv2(bild,id);
figure(112)
imshow(id_final,[])
title('identity kernel');

% guassian blur kernel
guass=(1/16)*[1 2 1;2 4 2 ; 1 2 1]
guass_final= conv2(bild,guass);
figure(432)
imshow(guass_final,[])
title('guassian blur kernel');

% Sharpen kernel
Sharp=[0 -1 0;-1 5 -1 ; 0 -1 0]
Sharp_final= conv2(bild,Sharp);
figure(932)
imshow(Sharp_final,[])
title('Sharpen kernel');

