[y,Fs] = audioread('y.wav');
Ts=1/Fs;
L=length(y);
f=(-L/2:(L/2)-1)/(L*Ts)
ffty = fftshift(fft(y));
figure(2)
plot((f*pi*2),abs(ffty)); title("fft y"); xlabel("f(Hz)"); 

[corr, lags] = xcorr(y);
figure(1)
plot(lags,corr)
title("correlation"); xlabel("lag"); 

a = 306.9/1170
b = 211.4/1170
k1= 5500
k2= 9000

t = ((-length(y)/2: length(y)/2-1))./Fs;
time_y = ifftshift(abs(ffty));
figure(3)
plot(t,time_y);title("time domain"); xlabel("t"); 

alfa=0.3;
beta=0.2;

b=1;
a=zeros(1,k2+1);
a(1)=1;
a(k1+1)=alfa;
a(k2+1)=beta;
yfilter = filter(b,a,y)
audiowrite("filtered_sound.wav",yfilter,Fs)



figure(43)
freqz(Num)

ynum_filter = filter(Num,1, yfilter)
audiowrite("filtered_sound_num.wav",yfilter,Fs)

ynum_filter_fft= abs(fftshift(fft(ynum_filter)));
yfilter_fft = abs(fftshift(fft(yfilter)));

figure(5)
plot(yfilter_fft)
hold on
plot(ynum_filter_fft)
title("x and xprime")
xlabel("f(Hz)")
legend('x(f)`','x(f)','Location','Best')

time_ynum = ifftshift(abs(ynum_filter_fft));
time_yfilter = ifftshift(abs(yfilter_fft));

figure(6)
subplot(1,2,1)
plot(t,time_ynum)
title("x ")
subplot(1,2,2)
plot(t, time_yfilter)
title("xprime")
xlabel("t(sec))")


%bonus

yG_filter = filter(G,1, yfilter)
audiowrite("filtered_sound_G.wav",yG_filter,Fs)


yNUM4_filter = filter(Num5,1, yfilter)
audiowrite("filtered_sound_Num3.wav",yNUM4_filter,Fs)




 
