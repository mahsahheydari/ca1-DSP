I = imread('coffee.jpg');
H_av = fspecial('average',35);
H_disk= fspecial('disk',10);
H_sobel= fspecial('sobel');
H_gaussian= fspecial('gaussian',100, 0.9);
H_laplacian = fspecial('laplacian',0.1)
average = imfilter(I,H_av,'replicate'); 
disk = imfilter(I,H_disk,'replicate'); 
sobel = imfilter(I , H_sobel, 'replicate');
gaussian = imfilter( I , H_gaussian, 'replicate');
laplacian = imfilter( I , H_laplacian, 'replicate')

figure(1)
imshow(average); title("average filter")
figure(2)
imshow(disk); title("disk filter")
figure(3)
imshow(sobel); title("sobel filter")
figure(4)
imshow(gaussian); title("gaussian filter")
figure(5)
imshow(laplacian); title("laplacian filter")
