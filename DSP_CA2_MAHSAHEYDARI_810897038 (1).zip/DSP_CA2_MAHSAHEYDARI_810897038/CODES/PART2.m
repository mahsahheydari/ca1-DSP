p1=6400;
p2=12500;
A=0.55;
B=0.7;

[s,Fs] = audioread('s.wav');
bb=1;      
aa=zeros(1,p2+1);          
aa(1)=1;
aa(p1+1)=A;
aa(p2+1)=B;
noisy_s=filter(aa,bb,s);
audiowrite("noisy_s.wav",noisy_s,Fs);


noisy_s_filter = filter(bb,aa,noisy_s)
audiowrite("clean_s.wav",noisy_s_filter,Fs)