%%disk
disk_gray = rgb2gray(disk);
fft_disk_gray = fft2(double(disk_gray));
Mag_disk_gray = abs(fft_disk_gray);
fsh_disk_gray = fftshift(fft_disk_gray);
phase_disk_gray = angle(fft_disk_gray);
figure(23)
plot(abs(fftshift(fft_disk_gray))); title("Disk"); 
% phase_disk_gray_koli = abs(phase_disk_gray).*exp(1i*phase_disk_gray)
% logtrans_disk_gray = log(1 + abs(fsh_disk_gray));

%%sober
sobel_gray = rgb2gray(sobel);
fft_sobel_gray = fft2(double(sobel_gray));
Mag_sobel_gray = abs(fft_sobel_gray);
fsh_sobel_gray = fftshift(fft_sobel_gray);
phase_sobel_gray = angle(fft_sobel_gray);
figure(233)
plot(abs(fftshift(fft_sobel_gray)));title("Sobel"); 

% phase_sobel_gray_koli = abs(phase_sobel_gray).*exp(1i*phase_sobel_gray)
% logtrans_sobel_gray = log(1 + abs(fsh_sobel_gray));

%average
average_gray = rgb2gray(average);
fft_average_gray = fft2(double(average_gray));
Mag_average_gray = abs(fft_average_gray);
fsh_average_gray = fftshift(fft_average_gray);
phase_average_gray = angle(fft_average_gray);
figure(213)
plot(abs(fftshift(fft_average_gray))); title("average"); 
% phase_average_gray_koli = abs(phase_average_gray).*exp(1i*phase_average_gray)
% logtrans_average_gray = log(1 + abs(fsh_average_gray));

%gaussian
gaussian_gray = rgb2gray(gaussian);
fft_gaussian_gray = fft2(double(gaussian_gray));
Mag_gaussian_gray = abs(fft_gaussian_gray);
fsh_gaussian_gray = fftshift(fft_gaussian_gray);
phase_gaussian_gray = angle(fft_gaussian_gray);
figure(219)
plot(abs(fftshift(fft_gaussian_gray))); title("gaussian"); 
% phase_gaussian_gray_koli = abs(phase_gaussian_gray).*exp(1i*phase_gaussian_gray)
% logtrans_gaussian_gray = log(1 + abs(fsh_gaussian_gray));

%laplacian
laplacian_gray = rgb2gray(laplacian);
fft_laplacian_gray = fft2(double(laplacian_gray));
Mag_laplacian_gray = abs(fft_laplacian_gray);
fsh_laplacian_gray = fftshift(fft_laplacian_gray);
phase_laplacian_gray = angle(fft_laplacian_gray);
% phase_laplacian_gray_koli = abs(phase_laplacian_gray).*exp(1i*phase_laplacian_gray)
% logtrans_laplacian_gray = log(1 + abs(fsh_laplacian_gray));
figure(239)
plot(abs(fftshift(fft_laplacian_gray))); title("laplacian"); 


% figure(31) ; subplot(1,2,1); imshow(logtrans_average_gray, []); title("Magnitude average")
%  subplot(1,2,2);imshow(phase_average_gray_koli, []); title("phase average")
% 
% figure(3) ; subplot(1,2,1); imshow(logtrans_gaussian_gray, []); title("Magnitude gaussian")
%  subplot(1,2,2);imshow(phase_gaussian_gray_koli, []); title("phase gaussian")
%  
% figure(90) ; subplot(1,2,1); imshow(logtrans_sobel_gray, []); title("Magnitude sobel")
%  subplot(1,2,2);imshow(phase_sobel_gray_koli, []); title("phase sobel")
% 
% figure(939) ; subplot(1,2,1); imshow(logtrans_disk_gray, []); title("Magnitude disk")
%  subplot(1,2,2);imshow(phase_disk_gray_koli, []); title("phase disk")
%  
%  figure(93) ; subplot(1,2,1); imshow(logtrans_laplacian_gray, []); title("Magnitude laplacian")
%  subplot(1,2,2);imshow(phase_laplacian_gray_koli, []); title("phase laplacian")